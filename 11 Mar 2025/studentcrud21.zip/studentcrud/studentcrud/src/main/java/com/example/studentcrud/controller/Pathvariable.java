package com.example.studentcrud.controller;

public @interface Pathvariable {

}
