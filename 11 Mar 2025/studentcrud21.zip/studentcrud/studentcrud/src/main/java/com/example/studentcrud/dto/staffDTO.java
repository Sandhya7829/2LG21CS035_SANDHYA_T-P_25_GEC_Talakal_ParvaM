package com.example.studentcrud.dto;

public class staffDTO {
    
}
